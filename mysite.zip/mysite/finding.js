document.addEventListener("DOMContentLoaded", function () {
  // Favorite button toggle
  const stars = document.querySelectorAll(".fa-star");

  stars.forEach(star => {
    star.addEventListener("click", function () {
      this.classList.toggle("active");
    });
  });

  // Add click animation to all buttons
  const buttons = document.querySelectorAll(".tab-button, .actions i, .bottom-nav a");

  buttons.forEach(button => {
    button.addEventListener("click", function () {
      this.classList.add("clicked");
      setTimeout(() => this.classList.remove("clicked"), 200); // Remove animation class
    });
  });
});
